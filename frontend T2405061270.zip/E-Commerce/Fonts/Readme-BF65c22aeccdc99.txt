NOTE:
By installing or using this font, you agree to the Font Usage Agreement:  

- This is DEMO VERSION and only for PERSONAL USE.

- If you want to use it commercially, you can purchase a license throught the link below:

https://pixesia.com/mutiara-ramadhan/

- For custom or corporate licenses, please contact us at support@pixesia.com

- Donations are also appreciated and can be made through our PayPal account. https://paypal.me/pixesia

Be sure to check out our store for more great fonts https://pixesia.com and follow us on Instagram at @pixesia.std

Thanks
 
-------------------

INDONESIA:

CATATAN: Font ini Versi DEMO/Full Versi dan hanya untuk PENGGUNAAN PRIBADI! 

Tetapi setiap donasi sangat dihargai.

Akun Paypal untuk donasi: https://paypal.me/pixesia

Untuk keperluan komersil, silahkan membeli versi lengkap dan lisensi melalui link di bawah ini:

https://pixesia.com/mutiara-ramadhan/

Untuk lisensi custom atau corporate, silahkan kontak kami melalui email berikut: support@pixesia.com

Silahkan kunjungi website kami: https://pixesia.com/

Segala bentuk penggunaan font tanpa membeli lisensi terlebih dahulu maka akan kami kenakan lisensi perusahaan (corporate).

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami di : support@pixesia.com

Terima kasih.